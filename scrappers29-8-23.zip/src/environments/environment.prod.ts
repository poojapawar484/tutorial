export const environment = {
  production: true,
  url :"https://master.vehiscrap.com",
  firebase: {
    // apiKey: 'AIzaSyBAJICL9s0BadjIYE0f6OCuKjJKCFRLInc',
    // authDomain: 'phone-auth-9c3e3.firebaseapp.com',
    // projectId: 'phone-auth-9c3e3',
    // storageBucket: 'phone-auth-9c3e3.appspot.com',
    // messagingSenderId: '255150664883',
    // appId: '1:255150664883:web:ef8f193e6a3262ab92d4c6',
    apiKey: "AIzaSyBNR486lp_tnJWej7wBkcWSwzhf19tz740",
    authDomain: "phone-auth-d347a.firebaseapp.com",
    projectId: "phone-auth-d347a",
    storageBucket: "phone-auth-d347a.appspot.com",
    messagingSenderId: "542141242667",
    appId: "1:542141242667:web:eb14fc6ae6e973fe0bb96e"
  },
};
