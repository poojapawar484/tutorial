import { Component } from '@angular/core';

@Component({
  selector: 'app-servicesmain',
  templateUrl: './servicesmain.component.html',
  styleUrls: ['./servicesmain.component.scss']
})
export class ServicesmainComponent {

}
