import { Component } from '@angular/core';

@Component({
  selector: 'app-loginrequired',
  templateUrl: './loginrequired.component.html',
  styleUrls: ['./loginrequired.component.scss']
})
export class LoginrequiredComponent {

}
